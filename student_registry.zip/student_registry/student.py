class Student:
    def __init__(self, name, student_number,course):
        self.marks = []
        self.attendance = 0
        self.assignment_deadline = None
        self.name = name
        self.student_number = student_number
        self.course= course

    def display_student_info():
        pass


    def add_marks():
        pass


    def update_attendance():
        pass


    def student_type():
        pass


class full_time_student(Student):
    def student_type():
        pass


class part_time_student(Student):
    def student_type():
        pass
    


student1 = Student("Winston", 22201, "Actuarial Science")
print(student1.name)


 